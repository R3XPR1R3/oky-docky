
  # User-friendly Document Filing System

  This is a code bundle for User-friendly Document Filing System. The original project is available at https://www.figma.com/design/LeQNi7adDWuKnoonzraLm1/User-friendly-Document-Filing-System.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  