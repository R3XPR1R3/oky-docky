import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Toaster, toast } from 'sonner';
import { LandingPage } from './components/LandingPage';
import { DocumentSelection } from './components/DocumentSelection';
import { QuestionFlow } from './components/QuestionFlow';
import { ReviewPage } from './components/ReviewPage';
import { SuccessPage } from './components/SuccessPage';
import { ErrorDialog } from './components/ErrorDialog';

type Step = 'landing' | 'selection' | 'questions' | 'review' | 'success';

// Demo mode - set to true to use mock data without backend
const DEMO_MODE = true;
const API_URL = 'http://localhost:8000';

export default function App() {
  const [currentStep, setCurrentStep] = useState<Step>('landing');
  const [selectedTemplate, setSelectedTemplate] = useState<string | null>(null);
  const [formData, setFormData] = useState<Record<string, any>>({});
  const [pdfUrl, setPdfUrl] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleGetStarted = () => {
    setCurrentStep('selection');
  };

  const handleSelectDocument = (templateId: string) => {
    setSelectedTemplate(templateId);
    setCurrentStep('questions');
  };

  const handleCompleteQuestions = (data: Record<string, any>) => {
    setFormData(data);
    setCurrentStep('review');
  };

  const handleEditQuestions = () => {
    setCurrentStep('questions');
  };

  const generateMockPDF = (): string => {
    // Create a simple mock PDF for demo purposes
    const mockPdfContent = `%PDF-1.4
1 0 obj
<<
/Type /Catalog
/Pages 2 0 R
>>
endobj
2 0 obj
<<
/Type /Pages
/Kids [3 0 R]
/Count 1
>>
endobj
3 0 obj
<<
/Type /Page
/Parent 2 0 R
/Resources <<
/Font <<
/F1 <<
/Type /Font
/Subtype /Type1
/BaseFont /Helvetica
>>
>>
>>
/MediaBox [0 0 612 792]
/Contents 4 0 R
>>
endobj
4 0 obj
<<
/Length 55
>>
stream
BT
/F1 24 Tf
100 700 Td
(Form Generated Successfully!) Tj
ET
endstream
endobj
xref
0 5
0000000000 65535 f
0000000009 00000 n
0000000058 00000 n
0000000115 00000 n
0000000317 00000 n
trailer
<<
/Size 5
/Root 1 0 R
>>
startxref
422
%%EOF`;

    const blob = new Blob([mockPdfContent], { type: 'application/pdf' });
    return URL.createObjectURL(blob);
  };

  const handleSubmit = async () => {
    if (!selectedTemplate) return;

    setIsLoading(true);
    setError(null);

    // Demo mode - simulate PDF generation
    if (DEMO_MODE) {
      toast.success('Generating your document...');
      
      // Simulate network delay
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      const mockUrl = generateMockPDF();
      setPdfUrl(mockUrl);
      setCurrentStep('success');
      setIsLoading(false);
      toast.success('Document generated successfully!');
      return;
    }

    // Real backend mode
    try {
      const response = await fetch(`${API_URL}/api/render/${selectedTemplate}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ data: formData }),
        mode: 'cors',
      });

      if (!response.ok) {
        throw new Error(`Server error: ${response.status} ${response.statusText}`);
      }

      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      setPdfUrl(url);
      setCurrentStep('success');
      toast.success('Document generated successfully!');
    } catch (error) {
      console.error('Error generating PDF:', error);
      
      let errorMessage = 'Failed to generate PDF. ';
      
      if (error instanceof TypeError && error.message.includes('fetch')) {
        errorMessage += 'Cannot connect to the backend server. Please ensure the FastAPI server is running on http://localhost:8000 with CORS enabled.';
      } else if (error instanceof Error) {
        errorMessage += error.message;
      } else {
        errorMessage += 'An unexpected error occurred.';
      }
      
      setError(errorMessage);
      toast.error('Failed to generate document');
    } finally {
      setIsLoading(false);
    }
  };

  const handleStartOver = () => {
    setCurrentStep('landing');
    setSelectedTemplate(null);
    setFormData({});
    setPdfUrl(null);
    setError(null);
  };

  const handleCloseError = () => {
    setError(null);
  };

  return (
    <>
      <Toaster position="top-center" richColors />
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">
        <AnimatePresence mode="wait">
          {currentStep === 'landing' && (
            <motion.div
              key="landing"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.3 }}
            >
              <LandingPage onGetStarted={handleGetStarted} />
            </motion.div>
          )}

          {currentStep === 'selection' && (
            <motion.div
              key="selection"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.3 }}
            >
              <DocumentSelection onSelectDocument={handleSelectDocument} />
            </motion.div>
          )}

          {currentStep === 'questions' && selectedTemplate && (
            <motion.div
              key="questions"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.3 }}
            >
              <QuestionFlow
                templateId={selectedTemplate}
                initialData={formData}
                onComplete={handleCompleteQuestions}
                onBack={() => setCurrentStep('selection')}
              />
            </motion.div>
          )}

          {currentStep === 'review' && (
            <motion.div
              key="review"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.3 }}
            >
              <ReviewPage
                formData={formData}
                templateId={selectedTemplate!}
                onEdit={handleEditQuestions}
                onSubmit={handleSubmit}
                isLoading={isLoading}
              />
            </motion.div>
          )}

          {currentStep === 'success' && pdfUrl && (
            <motion.div
              key="success"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              transition={{ duration: 0.3 }}
            >
              <SuccessPage pdfUrl={pdfUrl} onStartOver={handleStartOver} />
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Error Dialog */}
      <ErrorDialog
        isOpen={!!error}
        message={error || ''}
        onClose={handleCloseError}
      />
    </>
  );
}
