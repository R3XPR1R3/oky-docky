import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { FileText, ArrowLeft, ChevronRight, Building2, User } from 'lucide-react';
import { Button } from './ui/button';

interface DocumentSelectionProps {
  onSelectDocument: (templateId: string) => void;
}

interface Template {
  id: string;
  title: string;
  description: string;
  icon: typeof FileText;
  category: 'personal' | 'business';
  popular: boolean;
}

const templates: Template[] = [
  {
    id: 'w9-2026',
    title: 'Form W-9',
    description: 'Request for Taxpayer Identification Number',
    icon: FileText,
    category: 'personal',
    popular: true,
  },
  {
    id: 'w4-2026',
    title: 'Form W-4',
    description: "Employee's Withholding Certificate",
    icon: FileText,
    category: 'personal',
    popular: true,
  },
];

export function DocumentSelection({ onSelectDocument }: DocumentSelectionProps) {
  const [selectedCategory, setSelectedCategory] = useState<'all' | 'personal' | 'business'>('all');
  const [hoveredId, setHoveredId] = useState<string | null>(null);

  const filteredTemplates = templates.filter(
    (t) => selectedCategory === 'all' || t.category === selectedCategory
  );

  return (
    <div className="min-h-screen">
      {/* Header */}
      <motion.header
        initial={{ y: -20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="border-b border-white/20 backdrop-blur-sm bg-white/40"
      >
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" className="rounded-full">
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-indigo-600 to-purple-600 flex items-center justify-center">
                <FileText className="w-5 h-5 text-white" />
              </div>
              <span className="text-lg font-semibold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
                Oky-Docky
              </span>
            </div>
          </div>
        </div>
      </motion.header>

      <div className="container mx-auto px-4 py-16 max-w-6xl">
        {/* Title Section */}
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.5 }}
          className="text-center mb-12"
        >
          <h1 className="text-5xl font-bold mb-4">
            Which form do you need?
          </h1>
          <p className="text-xl text-slate-600 max-w-2xl mx-auto">
            Choose a document and we'll guide you through it step by step
          </p>
        </motion.div>

        {/* Category Filter */}
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.1 }}
          className="flex items-center justify-center gap-4 mb-12"
        >
          <Button
            variant={selectedCategory === 'all' ? 'default' : 'outline'}
            onClick={() => setSelectedCategory('all')}
            className={
              selectedCategory === 'all'
                ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white'
                : ''
            }
          >
            All Forms
          </Button>
          <Button
            variant={selectedCategory === 'personal' ? 'default' : 'outline'}
            onClick={() => setSelectedCategory('personal')}
            className={
              selectedCategory === 'personal'
                ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white'
                : ''
            }
          >
            <User className="w-4 h-4 mr-2" />
            Personal
          </Button>
          <Button
            variant={selectedCategory === 'business' ? 'default' : 'outline'}
            onClick={() => setSelectedCategory('business')}
            className={
              selectedCategory === 'business'
                ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white'
                : ''
            }
          >
            <Building2 className="w-4 h-4 mr-2" />
            Business
          </Button>
        </motion.div>

        {/* Document Cards */}
        <div className="grid md:grid-cols-2 gap-6">
          {filteredTemplates.map((template, index) => (
            <motion.div
              key={template.id}
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              onHoverStart={() => setHoveredId(template.id)}
              onHoverEnd={() => setHoveredId(null)}
              onClick={() => onSelectDocument(template.id)}
              className="relative group cursor-pointer"
            >
              <div className="relative bg-white rounded-2xl p-8 shadow-lg border-2 border-slate-200 hover:border-indigo-400 transition-all duration-300 hover:shadow-xl">
                {template.popular && (
                  <div className="absolute -top-3 -right-3">
                    <div className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white px-4 py-1 rounded-full text-sm font-medium shadow-lg">
                      Popular
                    </div>
                  </div>
                )}

                <div className="flex items-start justify-between mb-6">
                  <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-indigo-100 to-purple-100 flex items-center justify-center">
                    <template.icon className="w-8 h-8 text-indigo-600" />
                  </div>
                  <motion.div
                    animate={{
                      x: hoveredId === template.id ? 5 : 0,
                    }}
                    transition={{ duration: 0.2 }}
                  >
                    <ChevronRight className="w-6 h-6 text-slate-400 group-hover:text-indigo-600 transition-colors" />
                  </motion.div>
                </div>

                <h3 className="text-2xl font-bold mb-2 group-hover:text-indigo-600 transition-colors">
                  {template.title}
                </h3>
                <p className="text-slate-600 mb-6 leading-relaxed">
                  {template.description}
                </p>

                <div className="flex items-center gap-4 text-sm">
                  <div className="flex items-center gap-1 text-slate-500">
                    <div className="w-2 h-2 rounded-full bg-green-500"></div>
                    <span>~5 minutes</span>
                  </div>
                  <div className="flex items-center gap-1 text-slate-500">
                    <div className="w-2 h-2 rounded-full bg-blue-500"></div>
                    <span>{template.category === 'personal' ? 'Personal' : 'Business'}</span>
                  </div>
                </div>

                {/* Hover Effect */}
                <motion.div
                  className="absolute inset-0 rounded-2xl bg-gradient-to-r from-indigo-600/5 to-purple-600/5 opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none"
                />
              </div>
            </motion.div>
          ))}
        </div>

        {/* Help Section */}
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.3 }}
          className="mt-12 text-center"
        >
          <div className="bg-white/60 backdrop-blur-sm rounded-2xl p-8 border border-slate-200">
            <h3 className="text-lg font-semibold mb-2">Not sure which form you need?</h3>
            <p className="text-slate-600 mb-4">
              Our smart assistant can help you figure it out
            </p>
            <Button variant="outline" className="rounded-full">
              Get Help Choosing
            </Button>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
